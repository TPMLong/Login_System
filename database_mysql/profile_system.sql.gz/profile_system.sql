-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2021 at 08:26 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `profile_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `postId` int(11) NOT NULL,
  `postImage` longtext DEFAULT NULL,
  `title` tinytext NOT NULL,
  `postDescription` longtext NOT NULL,
  `userId` int(11) NOT NULL,
  `postStatusId` int(11) NOT NULL,
  `dateCreate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`postId`, `postImage`, `title`, `postDescription`, `userId`, `postStatusId`, `dateCreate`) VALUES
(3, NULL, 'This is a post with no text', 'is it work?', 2, 1, '2013-01-21 01:09:35'),
(5, '5fffd1be0efff0.55995963.jpg', 'testing', 'testing this is a very longgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg text you ever see in this data', 2, 1, '2014-01-21 12:08:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `userUid` tinytext NOT NULL,
  `userGmail` tinytext NOT NULL,
  `userPwd` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userUid`, `userGmail`, `userPwd`) VALUES
(1, 'long', 'long@gmail.com', '$2y$10$gTsThXocHBxN6dYdsOyy/uGL.zhva2ujGt00jgau/ZKVy.b0S9a/a'),
(2, 'thanh', 'thanh@gmail.com', '$2y$10$mvG8BFYvXzF/TsqSJaajr.8.eoc8ceL1lVOSrHUemnH.0fnxhOUQq');

-- --------------------------------------------------------

--
-- Table structure for table `user_infor`
--

CREATE TABLE `user_infor` (
  `userId` int(11) NOT NULL,
  `userFirst` tinytext DEFAULT NULL,
  `userLast` tinytext DEFAULT NULL,
  `userPhone` int(11) DEFAULT NULL,
  `userImage` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_infor`
--

INSERT INTO `user_infor` (`userId`, `userFirst`, `userLast`, `userPhone`, `userImage`) VALUES
(2, NULL, '1234', 794408658, '5ffc6d2eaa2f16.36224676.jpg'),
(1, NULL, NULL, NULL, 'logo.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`postId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `postId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
